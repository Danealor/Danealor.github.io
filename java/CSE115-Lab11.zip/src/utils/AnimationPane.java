package utils;

import java.awt.Component;

import javax.swing.JLayeredPane;

public class AnimationPane extends JLayeredPane {
	private static final long serialVersionUID = 8354800156462605882L;

	@Override
	protected void addImpl(Component comp, Object constraints, int index) {
	    int layer;
	    int pos;
	    Object constr;
	     if (constraints instanceof StackConstraints) {
	        layer = ((StackConstraints)constraints).layer;
	        constr = ((StackConstraints)constraints).layoutConstraints;
	        setLayer(comp, layer);
	    } 
	     else if (constraints instanceof Integer) {
	    	layer = ((Integer)constraints).intValue();
	    	constr = null;
	    } 
	    else {
	        layer = getLayer(comp);
	        constr = constraints;
	    }

	    pos = insertIndexForLayer(layer, index);
	    super.addImpl(comp, constr, pos);
	    comp.validate();
	    comp.repaint();
	}
}
