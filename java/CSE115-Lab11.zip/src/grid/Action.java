package grid;

import java.awt.Point;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Observable;

import javax.swing.JButton;
import javax.swing.Timer;

public abstract class Action extends Observable {
	private static final double ANIMATION_STEP = 0.01d;
	
	protected HashMap<Point, JButton> _map;
	protected HashMap<JButton, Point> _origins;
	protected Timer _timer;
	
	public abstract HashMap<Point, Integer> getCreateRequest();
	public abstract HashSet<Point> getHideRequest();
	
	public void beginAnimation(HashMap<Point, JButton> map) {
		_map = map;
		_origins = new HashMap<JButton, Point>();
		
		for (JButton button : _map.values()) {
			_origins.put(button, button.getLocation());
		}
		
		_timer = new Timer((int)Math.round(ANIMATION_STEP * 1000d), (e) -> update());
		_timer.start();
	}
	
	public void cancelAnimation() {
		if (_timer != null)
			_timer.stop();
	}
	
	public Collection<JButton> getTiles() {
		return _map.values();
	}
	
	protected abstract void update();
}
