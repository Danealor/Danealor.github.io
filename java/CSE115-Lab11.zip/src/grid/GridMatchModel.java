package grid;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Observable;
import java.util.Random;
import java.sql.*;

public class GridMatchModel extends Observable {
	public static final int LEVEL_ONE_SIZE = 5;
	private static final String MySQL_URL = "jdbc:mysql://mysql5015.smarterasp.net/db_a12e89_cse115";
	private static final String MySQL_USERNAME = "a12e89_cse115";
	private static final String MySQL_PASSWORD = "345leader543";
	
	private ArrayList<ArrayList<Integer>> _grid;
	private int _numColors;
	private Point _selectedPoint;
	private Move _hintedMove;
	private int _size;
	private int _score;
	private int _totalScore;
	private int _totalHighscore;
	private boolean _newHighscore;
	private boolean _newTotalHighscore;
	
	private ArrayList<Integer> _highscores;
	private File _scoreFile;
	
	private static final Point[] ADJACENT_POINTS = new Point[]{
				new Point(-1, 0), 
			    new Point(1, 0),
			    new Point(0, 1),
			    new Point(0, -1)};
	
	public GridMatchModel(int size, int numColors) {
		_numColors = numColors;
		_selectedPoint = null;
		_size = size;
		_scoreFile = new File("highScore.txt");
		_highscores = new ArrayList<Integer>();
		
		_grid = new ArrayList<ArrayList<Integer>>(size);
		for (int i = 0; i < size; i++) {
			ArrayList<Integer> row = new ArrayList<Integer>(size);
			for (int j = 0; j < size; j++) {
				row.add(0);
			}
			_grid.add(row);
		}
		
		loadScores();
		randomizeTiles();
		registerDriver();
	}
	
	public void getMatchRegion(Point p, HashSet<Point> region) {
		HashSet<Point> adjacentPoints = getAdjacent(p);
		HashSet<Point> candidates = new HashSet<Point>();
		
		for (Point point : adjacentPoints) {
			candidates.addAll(getMatch(point));
		}
		
		region.addAll(candidates);
		
		for (Point candidate : candidates) {
			if (!region.contains(candidate))
				getMatchRegion(p, region);
		}
	}
	
	public boolean hasMatch() {
		return getMatch() != null;
	}
	
	public HashSet<Point> getMatch() {
		int eqNum;

		if (_grid.size() == 0)
			return null;
		
		HashSet<Point> match = new HashSet<Point>();
		
		// Check Rows
		for (int i = 0 ; i < _grid.size(); i++) {
			ArrayList<Integer> row = _grid.get(i);
			eqNum = -1;
			match.clear();
			
			for (int j = 0; j < row.size(); j++) {
				if (eqNum != row.get(j)) {
					if (match.size() >= 3)
						return match;
					match.clear();
				}
				match.add(new Point(j, i));
				eqNum = row.get(j);
			}
			
			if (match.size() >= 3)
				return match;
		}
		
		// Check Columns
		for (int j = 0 ; j < _grid.get(0).size(); j++) {
			eqNum = -1;
			match.clear();
			
			for (int i = 0; i < _grid.size(); i++) {
				ArrayList<Integer> row = _grid.get(i);
				
				if (eqNum != row.get(j)) {
					if (match.size() >= 3)
						return match;
					match.clear();
				}
				match.add(new Point(j, i));
				eqNum = row.get(j);
			}

			if (match.size() >= 3)
				return match;
		}
		
		return null;
	}
	
	public HashSet<Point> getMatch(Point point) {
		HashSet<Point> match = new HashSet<Point>();
		
		boolean reverse = false;
		int testColor = getTile(point);
		for (Point offset : ADJACENT_POINTS) {
			Point test = new Point(point);
			
			test.translate(offset.x, offset.y);
			while (test.x < _size && test.y < _size &&
				   test.x >= 0    && test.y >= 0    &&
				   getTile(test) == testColor) {
				match.add(new Point(test));
				test.translate(offset.x, offset.y);
			}
			
			if (reverse)
			{
				if (match.size() >= 2)
					break;
				match.clear();
			}
			reverse = !reverse;
		}
		
		if (match.size() >= 2)
			match.add(point);
		return match;
	}
	
	private HashSet<Point> getAdjacent(Point point) {
		HashSet<Point> adjacentPoints = new HashSet<Point>();
		for (Point offset : ADJACENT_POINTS) {
			Point test = new Point(point);
			test.translate(offset.x, offset.y);
			
			if (test.x < _size && test.y < _size &&
				test.x >= 0    && test.y >= 0)
				adjacentPoints.add(test);
		}
		return adjacentPoints;
	}
	
	public void dropMatch(HashSet<Point> match) {
		if (match == null) return;
		Random rand = new Random();
		
		addScore(3 + (match.size() - 3) * (match.size() - 3));
		
		for (Entry<Integer, HashSet<Point>> verticalMatch : cleanMatch(match).entrySet()) {
			int top = _size;
			HashMap<Point, Integer> dropTiles = new HashMap<Point, Integer>();
			
			for (Point point : verticalMatch.getValue()) {
				if (point.y < top)
					top = point.y;
			}
			
			for (int y = top - 1; y >= 0; y--) {
				Point pointToDrop = new Point(verticalMatch.getKey(), y);
				Point pointToDropTo = new Point(verticalMatch.getKey(), y + verticalMatch.getValue().size());
				
				dropTiles.put(pointToDrop, getTile(pointToDrop));
				
				swap(new Move(pointToDrop, pointToDropTo));
			}
			
			for (int y = 0; y < verticalMatch.getValue().size(); y++) {
				_grid.get(y).set(verticalMatch.getKey(), rand.nextInt(_numColors));
				
				dropTiles.put(new Point(verticalMatch.getKey(), y - verticalMatch.getValue().size()), _grid.get(y).get(verticalMatch.getKey()));
			}
			
			setChanged();
			notifyObservers(new Drop(dropTiles, verticalMatch.getValue().size()));
		}
	}
	
	private HashMap<Integer, HashSet<Point>> cleanMatch(HashSet<Point> match) {
		HashMap<Integer, HashSet<Point>> verticalPartition = new HashMap<Integer, HashSet<Point>>();
		for (Point point : match) {
			if (verticalPartition.containsKey(point.x))
				verticalPartition.get(point.x).add(point);
			else {
				HashSet<Point> verticalMatch = new HashSet<Point>();
				verticalMatch.add(point);
				verticalPartition.put(point.x, verticalMatch);
			}
		}
		return verticalPartition;
	}
	
	private void swap(Move move) {
		int temp = _grid.get(move.getPointA().y).get(move.getPointA().x);
		_grid.get(move.getPointA().y).set(move.getPointA().x, _grid.get(move.getPointB().y).get(move.getPointB().x));
		_grid.get(move.getPointB().y).set(move.getPointB().x, temp);
	}
	
	private boolean isAdjacent(Move move) {
		return Math.abs(move.getPointA().x - move.getPointB().x) + Math.abs(move.getPointA().y - move.getPointB().y) == 1;
	}
	
	public boolean isLegalMove(Move move, boolean executeIfLegal) {
		boolean legal = false;
		if (isAdjacent(move)) {
			swap(move);
			
			HashSet<Point> match_a = getMatch(move.getPointA());
			HashSet<Point> match_b = getMatch(move.getPointB());
			
			legal = match_a.size() >= 3 || match_b.size() >= 3;
			
			if (!executeIfLegal || !legal)
				swap(move); // Swap back
		}
		return legal;
	}
	
	public Move getHint() {
		Point point_a;
		Point point_b;
		Move move;
		
		for (int x = 0; x < _size; x++) {
			for (int y = 0; y < _size; y++) {
				point_a = new Point(x, y);
				
				if (x + 1 < _size) {
					point_b = new Point(x + 1, y);
					move = new Move(point_a, point_b);
					
					if (isLegalMove(move, false))
						return move;
				}
			
				if (y + 1 < _size) {
					point_b = new Point(x, y + 1);
					move = new Move(point_a, point_b);
					
					if (isLegalMove(move, false))
						return move;
				}
			}
		}
		
		return null;
	}
	
	public boolean hasLegalMove() {
		return getHint() != null;
	}
	
	public void showHint() {
		_hintedMove = getHint();
		
		setChanged();
		notifyObservers();
	}
	
	public void clearHint() {
		_hintedMove = null;
		setChanged();
	}
	
	public void select(Point point) {
		if (_selectedPoint == null) {
			_selectedPoint = point;
		}
		else {
			Move move = new Move(_selectedPoint, getTile(_selectedPoint), point, getTile(point));
			if (isLegalMove(move, true)) {
				clearHint();
				setChanged();
				notifyObservers(move);
			}
			_selectedPoint = null;
		}
		
		setChanged();
		notifyObservers();
	}
	
	public void randomizeTiles() {
		Random rand = new Random();
		
		for (int i = 0 ; i < _grid.size(); i++) {
			ArrayList<Integer> row = _grid.get(i);
			for (int j = 0; j < row.size(); j++) {
				row.set(j, rand.nextInt(_numColors));
			}
		}
		
		setChanged();
		notifyObservers(false);
	}
	
	public int getTile(Point point) {
		return _grid.get(point.y).get(point.x);
	}
	
	public Point getSelectedPoint() {
		return _selectedPoint;
	}
	
	public Move getHintedMove() {
		return _hintedMove;
	}
	
	public int getSize() {
		return _size;
	}
	
	public int getLevel() {
		return getSize() - LEVEL_ONE_SIZE + 1;
	}
	
	public void setLevel(int level) {
		setSize(LEVEL_ONE_SIZE + level - 1);
		clearScore();
	}
	
	public int getGoal() {
		return getSize() * 10;
	}
	
	public void clearScore() {
		_score = 0;
		_newHighscore = false;
		setChanged();
		notifyObservers();
	}
	
	public void clearTotalScore() {
		_totalScore = 0;
		_newTotalHighscore = false;
		setChanged();
		notifyObservers();
	}
	
	private void addScore(int score) {
		_score += score;
		_totalScore += score;
		
		boolean updateHighscores = false;
		if (_score > getHighscore()) {
			setHighscore(_score);
			_newHighscore = true;
			updateHighscores = true;
		}
		if (_totalScore > getTotalHighscore()) {
			setTotalHighscore(_totalScore);
			_newTotalHighscore = true;
			updateHighscores = true;
		}
		if (updateHighscores) {
			saveScores();
		}
		
		setChanged();
		notifyObservers();
	}
	
	public int getScore() {
		return _score;
	}
	
	public int getTotalScore() {
		return _totalScore;
	}
	
	public int getHighscore() {
		if (getLevel() > _highscores.size())
			return 0;
		return _highscores.get(getLevel() - 1);
	}
	
	public ArrayList<Integer> getHighscores() {
		return _highscores;
	}
	
	public boolean hasNewHighscore() {
		return _newHighscore;
	}
	
	public boolean hasNewTotalHighscore() {
		return _newTotalHighscore;
	}
	
	private void setHighscore(int score) {
		setHighscore(score, getLevel());
	}
	
	private void setHighscore(int score, int level) {
		while (_highscores.size() < level) {
			_highscores.add(0);
		}
		_highscores.set(level - 1, score);
	}
	
	public int getTotalHighscore() {
		return _totalHighscore;
	}
	
	private void setTotalHighscore(int score) {
		_totalHighscore = score;
	}
	
	// Preserves sub-grid
	public void setSize(int size) {
		Random rand = new Random();
		
		for (int i = 0; i < Math.max(_size, size); i++)
		{
			ArrayList<Integer> row;
			if (i >= _size)
			{
				row = new ArrayList<Integer>();
				for (int j = 0; j < size; j++)
					row.add(rand.nextInt(_numColors));
				_grid.add(row);
			}
			else if (i >= size) {
				_grid.remove(_grid.size() - 1);
			}
			else
			{
				row = _grid.get(i);
				for (int j = 0; j < size; j++) {
					if (j >= _size)
						row.add(rand.nextInt(_numColors));
					else if (j >= size)
						row.remove(row.size() - 1);
				}
			}
		}
		
		_size = size;
		
		setChanged();
		notifyObservers(true);
	}
	
	private void registerDriver() {
		try {
		   Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(ClassNotFoundException ex) {
		   System.out.println("Error: unable to load driver class!");
		}
		catch(IllegalAccessException ex) {
		   System.out.println("Error: access problem while loading!");
		}
		catch(InstantiationException ex) {
		   System.out.println("Error: unable to instantiate driver!");
		}
	}
	
	public ArrayList<LeaderboardEntry> getLeaderboards() {
		Connection connection = null;
		Statement statement = null;
		ResultSet results = null;
		
		ArrayList<LeaderboardEntry> leaderboards = new ArrayList<LeaderboardEntry>();
		
		try {
			connection = DriverManager.getConnection(MySQL_URL, MySQL_USERNAME, MySQL_PASSWORD);
			statement = connection.createStatement();
			results = statement.executeQuery("SELECT * FROM leader ORDER BY score DESC LIMIT 10");
			while (results.next()) {
				leaderboards.add(new LeaderboardEntry(results.getString(1), results.getInt(2)));
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return leaderboards;
	}
	
	public void saveLeaderboards(String name, int score) {
		Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			connection = DriverManager.getConnection(MySQL_URL, MySQL_USERNAME, MySQL_PASSWORD);
			statement = connection.prepareStatement("INSERT INTO leader (name, score) VALUES(?, ?) ON DUPLICATE KEY UPDATE score=GREATEST(score, ?)");
			statement.setString(1, name);
			statement.setString(3, name);
			statement.setInt(2, score);
			statement.setInt(4, score);
			statement.execute();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		_newTotalHighscore = false;
	}
	
	private void loadScores() {
		if (!_scoreFile.exists()) {
			saveScores();
		}
		else if (_scoreFile.canRead()) {
			FileReader reader = null;
			BufferedReader bufferedReader = null;
			try {
				reader = new FileReader(_scoreFile);
				bufferedReader = new BufferedReader(reader);
				
				String line = bufferedReader.readLine();
				if (line != null)
					setTotalHighscore(Integer.parseInt(line));
				
				for (int i = 1; (line = bufferedReader.readLine()) != null; i++) {
					setHighscore(Integer.parseInt(line), i);
				}
			} 
			catch (IOException e) { }
			finally {
				try {
					if (bufferedReader != null)
						bufferedReader.close();
				}
				catch (IOException e) { }
				
				try {
					if (reader != null)
						reader.close();
				}
				catch (IOException e) { }
			}
		}
	}
	
	private void saveScores() {
		if (!_scoreFile.exists()) {
			try {
				_scoreFile.createNewFile();
			} 
			catch (IOException e) { }
		}
		
		if (_scoreFile.canWrite()) {
			FileWriter writer = null;
			BufferedWriter bufferedWriter = null;
			try {
				writer = new FileWriter(_scoreFile);
				bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.write(String.valueOf(getTotalHighscore()));
				
				for (int score : _highscores) {
					bufferedWriter.newLine();
					bufferedWriter.write(String.valueOf(score));
				}
			} 
			catch (IOException e) { }
			finally {
				try {
					if (bufferedWriter != null)
						bufferedWriter.close();
				}
				catch (IOException e) { }
				
				try {
					if (writer != null) {
						writer.close();
					}
				}
				catch (IOException e) { }
			}
		}
	}
}
