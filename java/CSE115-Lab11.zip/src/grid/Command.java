package grid;

public enum Command {
	Swap,
	Fill,
	Drop
}