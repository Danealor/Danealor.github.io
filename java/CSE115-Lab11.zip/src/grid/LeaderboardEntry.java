package grid;

public class LeaderboardEntry {
	public String name;
	public int score;
	
	public LeaderboardEntry(String name, int score) {
		this.name = name;
		this.score = score;
	}
}
