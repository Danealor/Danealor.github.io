package grid;

import java.awt.Color;
import java.awt.Point;
import java.util.Observable;

import javax.swing.JLabel;
import javax.swing.Timer;

public class FloatingText extends Observable {
	private static final double ANIMATION_STEP = 0.01d;
	private static final double TIME_STEP = 0.015d;
	private static final double VELOCITY = 0.4d;
	
	private Timer _timer;
	private JLabel _label;
	
	private float _opacity;
	private double _deltaY;
	private Point _origin;
	
	public FloatingText(JLabel label) {
		_label = label;
	}
	
	public JLabel getLabel() {
		return _label;
	}
	
	public void beginAnimation() {
		_origin = _label.getLocation();
		_deltaY = 0d;
		_opacity = 1f;
		
		_timer = new Timer((int)Math.round(ANIMATION_STEP * 1000d), (e) -> update());
		_timer.start();
	}
	
	public void cancelAnimation() {
		if (_timer != null)
			_timer.stop();
	}
	
	private void update() {
		_deltaY -= VELOCITY;
		_opacity -= TIME_STEP;
		
		boolean finish = false;
		if (_opacity <= 0f) {
			_opacity = 0f;
			finish = true;
		}
		
		Point location = new Point(_origin);
		location.translate(0, (int)Math.round(_deltaY));
		
		_label.setLocation(location);
		_label.setForeground(new Color(1f, 0f, 0f, _opacity));
		
		if (finish) {
			_timer.stop();
			setChanged();
			notifyObservers();
		}
	}
}
