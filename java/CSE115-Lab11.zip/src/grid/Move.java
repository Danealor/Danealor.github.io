package grid;

import java.awt.Point;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.JButton;

public class Move extends Action {
	private static final double MAX_PROGRESS = Math.PI * 2;
	private static final double TIME_STEP = 0.1d;
	
	private Point _point_a;
	private Point _point_b;
	private int _color_a;
	private int _color_b;
	
	private double _animationProgress;
	private double _multiplier;
	
	public Move(Point point_a, Point point_b) {
		_point_a = point_a;
		_point_b = point_b;
		_color_a = 0;
		_color_b = 0;
	}
	
	public Move(Point point_a, int color_a, Point point_b, int color_b) {
		_point_a = point_a;
		_point_b = point_b;
		_color_a = color_a;
		_color_b = color_b;
	}
	
	public Point getPointA() {
		return _point_a;
	}
	
	public Point getPointB() {
		return _point_b;
	}
	
	public int getColorA() {
		return _color_a;
	}
	
	public int getColorB() {
		return _color_b;
	}
	
	// Integral of movement function v(t) = cos(3t)-9cos(t)+8
	//								 x(t) = 8t-9sin(t)+sin(3t)/3
	private double getDistance(double time) {
		return (8 * time - 9 * Math.sin(time) + Math.sin(3 * time) / 3) * _multiplier;
	}

	@Override
	public HashMap<Point, Integer> getCreateRequest() {
		HashMap<Point, Integer> createRequest = new HashMap<Point, Integer>();
		
		createRequest.put(_point_a, _color_a);
		createRequest.put(_point_b, _color_b);
		
		return createRequest;
	}
	
	@Override
	public HashSet<Point> getHideRequest() {
		HashSet<Point> hideRequest = new HashSet<Point>();
		
		hideRequest.add(_point_a);
		hideRequest.add(_point_b);
		
		return hideRequest;
	}
	
	private static double distance(Point point_a, Point point_b) {
		return Point.distance(point_a.x, point_a.y, point_b.x, point_b.y);
	}

	@Override
	public void beginAnimation(HashMap<Point, JButton> map) {
		_animationProgress = 0d;
		
		double deltaX = distance(map.get(_point_a).getLocation(), map.get(_point_b).getLocation());
		
		_multiplier = 1d;
		_multiplier = deltaX / getDistance(MAX_PROGRESS);
		
		super.beginAnimation(map);
	}
	
	@Override
	public void cancelAnimation() {
		_animationProgress = 2d * Math.PI;
	}

	@Override
	public void update() {
		_animationProgress += TIME_STEP;
		
		boolean finish = false;
		if (_animationProgress >= MAX_PROGRESS) {
			_animationProgress = MAX_PROGRESS;
			finish = true;
		}
		
		double deltaX = getDistance(_animationProgress);

		JButton button_a = _map.get(_point_a);
		JButton button_b = _map.get(_point_b);
		
		Point location_a = new Point(_origins.get(button_a));
		Point location_b = new Point(_origins.get(button_b));
		
		if (_point_a.x > _point_b.x) {
			location_a.translate(-(int)Math.round(deltaX), 0);
			location_b.translate((int)Math.round(deltaX), 0);
		}
		else if (_point_a.x < _point_b.x) {
			location_a.translate((int)Math.round(deltaX), 0);
			location_b.translate(-(int)Math.round(deltaX), 0);
		}
		else if (_point_a.y > _point_b.y) {
			location_a.translate(0, -(int)Math.round(deltaX));
			location_b.translate(0, (int)Math.round(deltaX));
		}
		else if (_point_a.y < _point_b.y) {
			location_a.translate(0, (int)Math.round(deltaX));
			location_b.translate(0, -(int)Math.round(deltaX));
		}
		
		button_a.setLocation(location_a);
		button_b.setLocation(location_b);
		
		if (finish) {
			_timer.stop();
			setChanged();
			notifyObservers();
		}
	}
}
