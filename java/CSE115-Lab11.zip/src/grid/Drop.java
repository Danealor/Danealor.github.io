package grid;

import java.awt.Point;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.JButton;

public class Drop extends Action {
	private static final double DROP_ACCELERATION = 9.8d;
	private static final double TIME_STEP = 0.01d;
	
	private HashMap<Point, Integer> _tiles;
	private int _dropAmount;
	private double _velocity;
	private double _deltaY;
	private double _maxDeltaY;
	
	public Drop(HashMap<Point, Integer> tiles, int dropAmount) {
		_tiles = tiles;
		_dropAmount = dropAmount;
	}
	
	@Override
	public HashMap<Point, Integer> getCreateRequest() {
		return _tiles;
	}
	
	@Override
	public HashSet<Point> getHideRequest() {
		HashSet<Point> hideRequest = new HashSet<Point>();
		
		for (Point point : _tiles.keySet()) {
			hideRequest.add(new Point(point.x, point.y + _dropAmount));
		}
		
		return hideRequest;
	}
	
	public int getDropAmount() {
		return _dropAmount;
	}

	@Override
	public void beginAnimation(HashMap<Point, JButton> map) {
		if (map.size() > 0) {
			_maxDeltaY = (map.values().iterator().next().getHeight() + 4) * _dropAmount;
		}
		_velocity = 0d;
		super.beginAnimation(map);
	}
	
	@Override
	public void cancelAnimation() {
		_deltaY = _maxDeltaY;
	}

	@Override
	public void update() {
		_deltaY += _velocity * TIME_STEP + DROP_ACCELERATION * TIME_STEP * TIME_STEP / 2;
		
		boolean finish = false;
		if (_deltaY >= _maxDeltaY) {
			_deltaY = _maxDeltaY;
			finish = true;
		}
		
		for (Point point : _tiles.keySet()) {
			JButton button = _map.get(point);
			Point location = new Point(_origins.get(button));
			location.translate(0, (int)Math.round(_deltaY));
			button.setLocation(location);
		}
		
		_velocity += DROP_ACCELERATION;
		
		if (finish) {
			_timer.stop();
			setChanged();
			notifyObservers();
		}
	}
}
