package grid;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import grid.GridMatchModel;
import utils.AnimationPane;
import utils.StackConstraints;

public class GridMatchFrame extends JFrame implements Runnable, ActionListener, Observer {
	private static final long serialVersionUID = -3335595367577638461L;
	public static final String USER_NAME = "Amit Blonder";
	
	private final Object[] winOptions = {"Quit", "Restart", "Next Level" };
	private final Object[] loseOptions = {"Quit", "Restart" };
	
	private ImageIcon _winIcon;
	private ImageIcon _loseIcon;

	private ArrayList<ArrayList<JButton>> _tileButtons;
	private ArrayList<ImageIcon> _tileIcons;
	
	private HashSet<Action> _activeActions;

	private AnimationPane _animationPane;
	private JPanel _menuPanel;
	private JPanel _buttonPanel;
	
	private JLabel _totalScoreLabel;
	private JLabel _totalHighscoreLabel;
	private JLabel _levelScoreLabel;
	private JLabel _levelHighscoreLabel;
	
	private TitledBorder _levelBorder;
	
	private GridMatchModel _model;

	@Override
	public void run() {
		setTitle(USER_NAME + "'s Lab 11");
		setIconImage(_winIcon.getImage());
		
		CompoundBorder compoundBorder = BorderFactory.createCompoundBorder(
				BorderFactory.createBevelBorder(BevelBorder.RAISED),
				BorderFactory.createBevelBorder(BevelBorder.LOWERED));

		_animationPane = new AnimationPane();
		_animationPane.setLayout(new GridBagLayout());
		_animationPane.setBorder(compoundBorder);
		add(_animationPane, BorderLayout.WEST);
		
		_menuPanel = new JPanel();
		_menuPanel.setBorder(compoundBorder);
		_menuPanel.setLayout(new BoxLayout(_menuPanel, BoxLayout.PAGE_AXIS));
		add(_menuPanel, BorderLayout.EAST);
		
		_totalScoreLabel = new JLabel("0");
		_totalHighscoreLabel = new JLabel("0");
		_levelScoreLabel = new JLabel("0");
		_levelHighscoreLabel = new JLabel("0");
		
		createScorePanel("Total", _totalScoreLabel, _totalHighscoreLabel, _menuPanel);
		_levelBorder = (TitledBorder)createScorePanel("Level", _levelScoreLabel, _levelHighscoreLabel, _menuPanel).getBorder();
		
		_menuPanel.add(Box.createVerticalGlue());

		_buttonPanel = new JPanel();
		_menuPanel.add(_buttonPanel);
		_buttonPanel.setLayout(new GridLayout(0, 1));
		
		createButton(this, _buttonPanel, "Show Hint");
		createButton(this, _buttonPanel, "Highscores");
		createButton(this, _buttonPanel, "Leaderboards");

	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Let's not have them win immediately
		while (_model.hasMatch() || !_model.hasLegalMove())
			_model.randomizeTiles();
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) 
			{
				if (_model.getTotalScore() >= _model.getTotalHighscore()) {
					promptSaveLeaderboard();
				}
				System.out.println("Total score was: " + _model.getTotalScore());
			}
		});
		
		_model.addObserver(this);
		
		updateUI();
		
		setVisible(true);
	}
	
	public GridMatchFrame() {
		_tileIcons = new ArrayList<ImageIcon>(6);
		_tileIcons.add(new ImageIcon("Images/Tile-0.png"));
		_tileIcons.add(new ImageIcon("Images/Tile-1.png"));
		_tileIcons.add(new ImageIcon("Images/Tile-2.png"));
		_tileIcons.add(new ImageIcon("Images/Tile-3.png"));
		_tileIcons.add(new ImageIcon("Images/Tile-4.png"));
		_tileIcons.add(new ImageIcon("Images/Tile-5.png"));
		
		_winIcon = new ImageIcon("Images/game_finish.png");
		_loseIcon = new ImageIcon("Images/game_over.png");
		
		_tileButtons = new ArrayList<ArrayList<JButton>>();
		_activeActions = new HashSet<Action>();
		
		_model = new GridMatchModel(GridMatchModel.LEVEL_ONE_SIZE, _tileIcons.size());
	}
	
	private void convertToAbsolute() {
		_animationPane.setLayout(null);
		_animationPane.setPreferredSize(_animationPane.getSize());
	}
	
	private void endLevel() {
		if (_model.getScore() >= _model.getGoal()) {
			switch  (JOptionPane.showOptionDialog(this,
					"No more moves available! Next level?", 
					"LEVEL END", 
					JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.INFORMATION_MESSAGE,
					_winIcon,
					winOptions,
					winOptions[2])) {
			case 0:
				if (_model.hasNewTotalHighscore()) {
					promptSaveLeaderboard();
				}
				System.exit(0);
				break;
			case 1:
				if (_model.hasNewTotalHighscore()) {
					promptSaveLeaderboard();
				}
				_model.setLevel(1);
				_model.randomizeTiles();
				while (_model.hasMatch() || !_model.hasLegalMove())
					_model.randomizeTiles();
				_model.clearTotalScore();
				break;
			case 2:
				_model.setLevel(_model.getLevel() + 1);
				_model.randomizeTiles();
				while (_model.hasMatch() || !_model.hasLegalMove())
					_model.randomizeTiles();
				break;
			default:
				break;
			}
		}
		else {
			switch  (JOptionPane.showOptionDialog(this,
					"No more moves available! Game Over!", 
					"GAME OVER", 
					JOptionPane.YES_NO_OPTION,
					JOptionPane.ERROR_MESSAGE,
					_loseIcon,
					loseOptions,
					loseOptions[1])) {
			case 0:
				if (_model.hasNewTotalHighscore()) {
					promptSaveLeaderboard();
				}
				System.exit(0);
				break;
			case 1:
				if (_model.hasNewTotalHighscore()) {
					promptSaveLeaderboard();
				}
				_model.setLevel(1);
				_model.randomizeTiles();
				while (_model.hasMatch() || !_model.hasLegalMove())
					_model.randomizeTiles();
				_model.clearTotalScore();
				break;
			default:
				break;
			}
		}
	}
	
	private void promptSaveLeaderboard() {
		switch  (JOptionPane.showConfirmDialog(this,
				"You reached a new total highscore of " + _model.getTotalHighscore() + ".\nWould you like to upload to the leaderboards?", 
				"New Highscore!", 
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE)) {
		case JOptionPane.YES_OPTION:
			final TextField nameTextField = new TextField("" , 20);
			
			final JOptionPane optionPane = new JOptionPane(
					new Object[] {
	                "Input your nickname: \n",
	                nameTextField},
	                JOptionPane.PLAIN_MESSAGE,
	                JOptionPane.OK_CANCEL_OPTION);

			final JDialog dialog = new JDialog(this, 
			                             "Leaderboards",
			                             true);
			
			optionPane.addPropertyChangeListener(
				    new PropertyChangeListener() {
				        public void propertyChange(PropertyChangeEvent e) {
				            String prop = e.getPropertyName();

				            if (dialog.isVisible() 
				             && (e.getSource() == optionPane)
				             && (prop.equals(JOptionPane.VALUE_PROPERTY))) {
				            	if (optionPane.getValue().equals(JOptionPane.OK_OPTION)) {
				            		String name = nameTextField.getText();
				            		optionPane.setMessage("Saving...");
				            		dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
				            		dialog.addWindowListener(new WindowAdapter() {
				            		    public void windowClosing(WindowEvent we) { }
				            		});
				            		dialog.pack();
				            		new Thread(() -> {
					            		_model.saveLeaderboards(name, _model.getTotalHighscore());
					            		dialog.setVisible(false);
				        			}).start();
				            	}
				            	else
				            		dialog.setVisible(false);
				            }
				        }
				    });
			
			dialog.setContentPane(optionPane);
			dialog.pack();
			dialog.setVisible(true);
			break;
		default:
			break;
		}
	}
	
	private void updateUI() {
		if (_model.getSize() != _tileButtons.size())
			updateGrid();
		updateTiles();
		
		_levelBorder.setTitle("Level " + _model.getLevel());
		
		_levelScoreLabel.setText(String.valueOf(_model.getScore()) + "/" + _model.getGoal());
		_levelScoreLabel.setForeground(_model.getScore() >= _model.getGoal() ? Color.GREEN : Color.RED);
		
		_totalScoreLabel.setText(String.valueOf(_model.getTotalScore()));
		
		_levelHighscoreLabel.setText(String.valueOf(_model.getHighscore()));
		_levelHighscoreLabel.setForeground(_model.hasNewHighscore() ? Color.BLUE : Color.BLACK);
		
		_totalHighscoreLabel.setText(String.valueOf(_model.getTotalHighscore()));
		_totalHighscoreLabel.setForeground(_model.hasNewTotalHighscore() ? Color.BLUE : Color.BLACK);
		
		pack();
	}
	
	private void updateTiles() {
		Point selectedPoint = _model.getSelectedPoint();
		Point hintedPointA = null;
		Point hintedPointB = null;
		
		if (_model.getHintedMove() != null) {
			hintedPointA = _model.getHintedMove().getPointA();
			hintedPointB = _model.getHintedMove().getPointB();
		}
		
		for (int i = 0; i < _model.getSize(); i++) {
			ArrayList<JButton> row = _tileButtons.get(i);
			for (int j = 0; j < _model.getSize(); j++) {
				JButton button = row.get(j);
				Point point = new Point(j, i);
				
				row.get(j).setIcon(_tileIcons.get(_model.getTile(new Point(j, i))));
				if (point.equals(selectedPoint)) {
					button.setBackground(Color.RED);
				}
				else if (point.equals(hintedPointA) || point.equals(hintedPointB)) {
					button.setBackground(Color.BLUE);
				}
				else {
					button.setBackground(Color.WHITE);
				}
			}
		}
	}
	
	private void updateGrid() {
		// Convert back to grid layout and recreate all tiles upon new level
		_animationPane.setLayout(new GridBagLayout());
		_animationPane.setPreferredSize(null);
		
		// Clear current layout
		_animationPane.removeAll();
		_tileButtons.clear();
		
		for (int i = 0; i < _model.getSize(); i++) {
			ArrayList<JButton> row = new ArrayList<JButton>();
			for (int j = 0; j < _model.getSize(); j++)
				row.add(createTile(this, _animationPane, j, i));
			_tileButtons.add(row);
		}
		
		_animationPane.repaint();
	}
	
	private static JButton createButton(ActionListener listener, Container container, String command) {
		JButton button = new JButton(command);
		button.addActionListener(listener);
		button.setMargin(new Insets(2, 2, 2, 2));
		button.setActionCommand(command);
		
		container.add(button);
		return button;
	}
	
	private static JButton createButton(ActionListener listener, Container container, String command, int gridx, int gridy) {
		JButton button = new JButton();
		button.addActionListener(listener);
		button.setMargin(new Insets(2, 2, 2, 2));
		button.setActionCommand(command);
		
		place(button, container, gridx, gridy, new Insets(2, 2, 2, 2));
		return button;
	}
	
	private void setTilesVisible(HashSet<Point> requestedButtons, boolean visible) {
		for (Point point : requestedButtons) {
			_tileButtons.get(point.y).get(point.x).setVisible(visible);
		}
	}
	
	private JLabel createFloatingText(HashSet<Point> source) {
		convertToAbsolute();
		JLabel label = new JLabel("+" + String.valueOf(3 + (source.size() - 3) * (source.size() - 3)));
		label.setForeground(Color.RED);
		
		Point pointTotal = new Point(0, 0);
		
		for (Point p : source) {
			Point location = _tileButtons.get(p.y).get(p.x).getLocation();
			pointTotal.translate(location.x, location.y);
		}
		
		label.setBounds((int)Math.round(pointTotal.x / source.size()) + 25, (int)Math.round(pointTotal.y / source.size()), 50, 50);
		_animationPane.add(label, new Integer(2));
		
		return label;
	}
	
	private HashMap<Point, JButton> createTiles(HashMap<Point, Integer> requestedButtons) {
		HashMap<Point, JButton> buttons = new HashMap<Point, JButton>();
		convertToAbsolute();
		
		for (Entry<Point, Integer> entry : requestedButtons.entrySet()) {
			Point point = entry.getKey();
			int color = entry.getValue();
			
			Point location;
			
			if (point.y >= 0) {
				location = _tileButtons.get(point.y).get(point.x).getLocation();
			}
			else {
				location = _tileButtons.get(0).get(point.x).getLocation();
				location.translate(0, point.y * (_tileButtons.get(0).get(point.x).getHeight() + 4));
			}
			
			JButton button = new JButton();
			button.setMargin(new Insets(2, 2, 2, 2));
			button.setIcon(_tileIcons.get(color));
			button.setBounds(new Rectangle(location, _tileButtons.get(0).get(point.x).getSize()));
			_animationPane.add(button, new Integer(1));
			buttons.put(point, button);
		}
		
		return buttons;
	}
	
	private static JButton createTile(ActionListener listener, Container container, int gridx, int gridy) {
		return createButton(listener, container, gridx + "," + gridy, gridx, gridy);
	}
	
	private static JPanel createScorePanel(String title, JLabel score, JLabel highscore, Container container) {
		JPanel scorePanel = new JPanel();
		scorePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED), title));
		scorePanel.setMaximumSize(new Dimension(1000, 0));
		scorePanel.setLayout(new BoxLayout(scorePanel, BoxLayout.PAGE_AXIS));
		
		JPanel topPanel = new JPanel();
		JPanel botPanel = new JPanel();
		
		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.LINE_AXIS));
		botPanel.setLayout(new BoxLayout(botPanel, BoxLayout.LINE_AXIS));
		
		JLabel scoreLabel = new JLabel("Score: ");
		topPanel.add(scoreLabel);
		topPanel.add(Box.createHorizontalGlue());
		topPanel.add(score);
		
		JLabel highscoreLabel = new JLabel("Highscore: ");
		botPanel.add(highscoreLabel);
		botPanel.add(Box.createHorizontalGlue());
		botPanel.add(highscore);
		
		scorePanel.add(topPanel);
		scorePanel.add(botPanel);
		
		container.add(scorePanel);
		return scorePanel;
	}
	
	private static void place(JComponent component, Container container, int gridx, int gridy, Insets insets) {
		place(component, container, gridx, gridy, insets, GridBagConstraints.CENTER);
	}
	
	private static void place(JComponent component, Container container, int gridx, int gridy, Insets insets, int constraint) {
		if (!(container.getLayout() instanceof GridBagLayout))
			container.setLayout(new GridBagLayout());
		GridBagConstraints layoutConst = new GridBagConstraints();
		
		layoutConst.gridx = gridx;
		layoutConst.gridy = gridy;
		layoutConst.anchor = constraint;
		
		if (insets != null)
			layoutConst.insets = insets;
		
		if (container instanceof AnimationPane) {
			container.add(component, new StackConstraints(0, layoutConst));
		}
		else {
			container.add(component, layoutConst);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "Show Hint":
			_model.showHint();
			break;
		case "Highscores":
			String message = "Total Highscore: " + _model.getTotalHighscore();
			for (int i = 0; i < _model.getHighscores().size(); i++) {
				message += "\nLevel " + String.valueOf(i + 1) + ": " + String.valueOf(_model.getHighscores().get(i));
			}
			
			JOptionPane.showMessageDialog(this,
				    message,
				    "Highscores",
				    JOptionPane.PLAIN_MESSAGE);
			break;
		case "Leaderboards":
			final JOptionPane optionPane = new JOptionPane(
	                "~~ Leaderboard ~~\n"
	                + "Loading...\n",
	                JOptionPane.PLAIN_MESSAGE,
	                JOptionPane.DEFAULT_OPTION);

			final JDialog dialog = new JDialog(this, 
			                             "Leaderboards",
			                             false);
			
			optionPane.addPropertyChangeListener(
				    new PropertyChangeListener() {
				        public void propertyChange(PropertyChangeEvent e) {
				            String prop = e.getPropertyName();

				            if (dialog.isVisible() 
				             && (e.getSource() == optionPane)
				             && (prop.equals(JOptionPane.VALUE_PROPERTY))) {
				                dialog.setVisible(false);
				            }
				        }
				    });
			
			dialog.setContentPane(optionPane);
			dialog.pack();
			dialog.setVisible(true);
			
			new Thread(() -> {
				ArrayList<LeaderboardEntry> leaderboard = _model.getLeaderboards();
				String msg = "~~ Leaderboard ~~";
				for (int i = 0; i < leaderboard.size(); i++) {
					msg += "\n" + (i + 1) + ". " + leaderboard.get(i).name + ": " + leaderboard.get(i).score;
				}
				
				optionPane.setMessage(msg);
				dialog.pack();
			}).start();
			break;
		default:
			String[] coords = e.getActionCommand().split(",");
			if (coords.length == 2) {
				try {
					int x = Integer.parseInt(coords[0]);
					int y = Integer.parseInt(coords[1]);
					_model.select(new Point(x, y));
				} 
				catch (NumberFormatException ex) { }
			}
			break;
		}
	}

	@Override
	public void update(Observable sender, Object arg) {
		if (sender == _model) {
			if (arg instanceof Action) {
				Action action = (Action)arg;
				_activeActions.add(action);
				action.addObserver(this);
				
				action.beginAnimation(createTiles(action.getCreateRequest()));
				setTilesVisible(action.getHideRequest(), false);
			}
			updateUI();
		}
		else if (sender instanceof Action) {
			Action action = (Action)sender;
			_activeActions.remove(action);
			
			for (JButton button : action.getTiles()) {
				_animationPane.remove(button);
			}
			
			setTilesVisible(action.getHideRequest(), true);
			
			if (_activeActions.size() == 0) {
				HashSet<Point> region = new HashSet<Point>();
				
				if (action instanceof Move) {
					_model.getMatchRegion(((Move)action).getPointA(), region);
				}
				else {
					region = _model.getMatch();
					if (region != null) {
						_model.getMatchRegion(region.iterator().next(), region);
					}
				}
				
				if (region != null && region.size() > 0) {
					FloatingText scoreLabel = new FloatingText(createFloatingText(region));
					scoreLabel.addObserver(this);
					scoreLabel.beginAnimation();
					_model.dropMatch(region);
				}
				else if (!_model.hasLegalMove()) {
					endLevel();
				}
			}
		}
		else if (sender instanceof FloatingText) {
			_animationPane.remove(((FloatingText)sender).getLabel());
		}
	}
}
